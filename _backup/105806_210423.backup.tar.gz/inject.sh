#!/bin/sh

eval ~/bin/slave
