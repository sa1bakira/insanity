#!/bin/sh

date +%c
date +%s
