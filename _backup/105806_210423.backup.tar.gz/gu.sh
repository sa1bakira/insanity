#!/bin/sh

#
# Backup of bin
#

ARCHIVE_NAME="$(date +%H%M%S_%d%m%y)".backup.tar.gz
BACKUP_DIR=/home/panku/websites/insanity/_backup

rm -fv "$BACKUP_DIR"/*.*

tar czfv "$BACKUP_DIR/$ARCHIVE_NAME" -C ~/bin .
chmod +x "$BACKUP_DIR/$ARCHIVE_NAME"

SHA_SIG="$(openssl sha256 "$BACKUP_DIR"/"$ARCHIVE_NAME" | cut -d ' ' -f2)"
SHA_SIG="$SHA_SIG $ARCHIVE_NAME"

echo "$SHA_SIG" > "$BACKUP_DIR"/sha256.txt


#
# Git add,commit,push
#
git -C /home/panku/websites/insanity status
git -C /home/panku/websites/insanity add -A
git -C /home/panku/websites/insanity commit -m "backup"
git -C /home/panku/websites/insanity push
