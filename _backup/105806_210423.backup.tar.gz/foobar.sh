#!/bin/sh

echo test

lol ()
{
  TMP="inside"

}

echo $TMP
