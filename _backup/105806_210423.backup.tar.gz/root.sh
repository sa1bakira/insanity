#!/bin/bash

xterm -bg darkred -fg white -fs 12 -geometry 60x20 -e 'su'
